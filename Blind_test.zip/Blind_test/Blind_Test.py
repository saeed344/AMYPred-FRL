from features import *
import pickle
from tabulate import tabulate

# Read protein sequences from file
fasta = read_protein_sequences('blind_test_dataset.fasta')

# Extract features for the sequences
xtest = amyfrl(fasta)

# Load the trained model
ldmodel = pickle.load(open("model/pima.pickle_model_svm_PF.dat", "rb"))
print("Loaded model from disk")

# Predict scores for each sequence
Threshold = 0.5  # Adjust threshold as needed
results = []

for i in range(len(fasta)):
    sequence = fasta[i][1]  # Extracting peptide sequence without numbering
    y_score = ldmodel.predict_proba(xtest[i].reshape(1, -1))[0][1]  # Probability of being AMY
    prediction = 'AMY' if y_score >= Threshold else 'non-AMY'
    results.append([sequence, y_score, prediction])

# Print results in a table
headers = ["Peptide Sequence", "Predicted Score", "Classification"]
print(tabulate(results, headers=headers, tablefmt="pretty"))
